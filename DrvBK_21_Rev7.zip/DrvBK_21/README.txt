DriverBackup! 2.0 created by Giuseppe Greco



1: INSTALLATION

Windows Vista: Requires only a simple "Copy & Paste" action.

Windows XP\Server 2003: Requires Microsoft .NET Framework 2.0 installed. Read help guide for more information.


***WARNING***** 

It is HIGHLY recommended to read program documentation to avoid wrong program use.



Giuseppe Greco, Palermo 30-11-2008